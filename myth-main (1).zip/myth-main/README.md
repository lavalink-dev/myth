# What is myth? And why should I use It?
> Myth is a multipurpose bot, aiming to protect communities from harm.
