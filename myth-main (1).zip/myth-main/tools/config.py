import discord 

class emoji:
    agree = "<:agree:1284945190473171056>"
    deny = "<:deny:1284945212833005568>"
    warn = "<:warn:1284945160429371544>"
    link = "<:link:1284944950097608724>"
    channel = "<:channel:1284955789118673078>"
    cmd = "<:slash:1284955888070950962>"

class color:
    default = 0x404148
    warn = discord.Color.yellow()
    deny = discord.Color.red()
    agree = discord.Color.green()
